# Whoop 65 with an original flight controller

Open [the offline aircraft viewer](Designs/Aircraft/viewer.html), [the design index](Designs/START-HERE.md) or [the Codex Desktop demo prompts](Presentation/Prompt-runbook.md). The design index also links the native KiCad project, fabrication files, full purchasing BOM and verification receipts. Read the [presenter's timed script](Presentation/Read-along.pdf) alongside the silent stage film.
