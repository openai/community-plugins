# Build the Whoop in Codex

To show the finished aircraft immediately, open the [offline 3D viewer](../Designs/Aircraft/viewer.html). The silent film has a [timed presenter script](Read-along.pdf). For a first rehearsal on another Apple silicon Mac, unpack the ZIP and follow [Prepare the Mac](../Designs/Runtime/README.md) once. It installs the pinned public plugins, prepares CAD and builds KiCad 9.0.2 from the supplied Dockerfile.

## Start a fresh design

Start a fresh chat in an empty writable folder and select **Physical Engineering** in the composer. Use KiCad for board design and **PCBA Engineering** for the board assembly handoff. Paste each prompt after the previous step finishes. These prompts can produce a new design. Use the exact replay below for the reviewed aircraft.

**1. Establish the aircraft**

```text
Build a 65 mm indoor FPV quad reference with four guarded 31 mm props, camera and removable 1S pack. Preserve the editable Whoop reference. Open its exported assembly, isolate the flight board and measure the four grommet bores and the board seat. Identify which functions the integrated board supplies.
```

**2. Design the replacement flight controller**

```text
Design an original four-layer KiCad controller with STM32F405RGT6, ICM-42688-P, an 8 MHz crystal and a 3.0 V regulator. Match the measured mount and 0.80 mm finished thickness. Provide 1S input, four motor signals and ground, receiver UART and SWD. Route the board, run ERC, DRC and schematic parity, and resolve open connections. Export native sources, Gerbers, drills, placement, exact-MPN BOM and the populated STEP.
```

**3. Fit the separate electronics**

```text
Integrate the actual new PCB, a purchased 1S/LiHV four-channel ESC, ELRS receiver, analog VTX and 5 V boost. Compare motor draw with the ESC, battery and connector ratings. Test a 2 mm dock lift against the exported propeller sweeps. Preserve any rejected candidate and design serviceable printed mounts around the result. Show measured STEP clearances. Mark supplier height allowances and unresolved physical cable routing.
```

**4. Publish a checked handoff**

```text
Deliver the aircraft STEP, colored GLB and offline viewer, installed component STEPs, printable STLs, editable sources and formatted aircraft/bench BOM. Count the control board once and reconcile its child BOM with placements. Link suppliers and identify remaining tests. Clean-rebuild the handoff and compare its measurements and files.
```

## Rehearse the reviewed release

Open the folder containing **Designs** and **Presentation** in Codex Desktop. Paste the following into one chat.

```text
Open Designs/Aircraft/viewer.html, explode the quad and isolate Whoop F405 Rev A. Inspect Designs/Evidence/dock-lift/readback.json and Designs/Procurement/aircraft-bom.xlsx. Rebuild Designs/Aircraft into a new Rehearsal folder with its shipped runner. Use Designs/Evidence/release/compare_handoffs.py to compare it with the original, then show the measured results and remaining hardware tests. Preserve the source kit.
```

The setup guide puts the CAD runtime where both Terminal and Codex Desktop discover it. From the kit root, rebuild into an unused destination.

```sh
mkdir -p Rehearsal
sh Designs/Aircraft/rebuild.sh Rehearsal/aircraft
python3 Designs/Evidence/release/compare_handoffs.py \
  Designs/Aircraft Rehearsal/aircraft Rehearsal/comparison.json
```

**Flight controller.** With the image prepared, this command creates an offline container, re-exports native manufacturing files, reads back the routed design and saves the results in a fresh folder.

```sh
sh Designs/Runtime/rebuild-flight-controller.sh Designs/Flight-controller Rehearsal/flight-controller
```

For native KiCad 9.0.2, use a fresh copy of the board folder and the [board export instructions](../Designs/Flight-controller/README.md). [Verified native rebuild](../Designs/Flight-controller/evidence/source-rebuild.json)

### What to show

| When | Open | Presenter cue |
| --- | --- | --- |
| Introduce the quad | [Aircraft viewer](../Designs/Aircraft/viewer.html) | Rotate to the camera, explode the stack, then isolate the custom board. |
| Explain the mechanical decision | [CAD readback](../Designs/Evidence/dock-lift/readback.json) | The original dock clears the full-diameter rotor gauges by 1.79 mm. Raising it 2.00 mm creates 4.56 mm³ of interference across two rear quadrants. |
| Show the real controller | [KiCad project](../Designs/Flight-controller/design/Whoop-F405-A.kicad_pro) | Show the controller and IMU, the routed layers and the four cardinal mounting ears. |
| Show what you would order | [Purchasing workbook](../Designs/Procurement/aircraft-bom.xlsx) · [IMU price check](../Designs/Evidence/release/imu-price-crosscheck.json) | One PCBA on the aircraft, 26 devices across 11 exact MPNs. The sourced fitted quantities for five boards total $170.60, before fabrication, loading losses, assembly and delivery. |
| Close with the handoff | [Rebuild receipt](../Designs/Evidence/release/reproduction.json) | Compare 84 standard checks, 52 additional stack checks and all four guard rims. The ESC's physical height, power interconnect, mass, wiring and flight behavior still need hardware. |
