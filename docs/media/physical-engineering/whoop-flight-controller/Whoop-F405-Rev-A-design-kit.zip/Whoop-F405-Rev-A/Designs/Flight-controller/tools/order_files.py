"""Translate KiCad BOM and centroids to JLC assembly import tables."""
import csv,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1]
CODES=dict(zip('STM32F405RGT6 ICM-42688-P TLV75530PDBVR X32258MOB4SI GRM188R71C104KA01D GRM188R71H103KA01D GRM188R71A225KE15D GRM188R61A475KE15D C0603C160J5GAC7867 RC0603FR-0710KL RC0603FR-07100KL'.split(),'C15742 C1850418 C507268 C2682775 C45000 C77053 C86018 C71633 C599683 C98220 C14675'.split()))
SUPPLIER_LINKS={'STM32F405RGT6': 'https://jlcpcb.com/partdetail/C15742', 'ICM-42688-P': 'https://jlcpcb.com/partdetail/C1850418', 'TLV75530PDBVR': 'https://jlcpcb.com/partdetail/C507268', 'X32258MOB4SI': 'https://jlcpcb.com/partdetail/C2682775', 'GRM188R71C104KA01D': 'https://jlcpcb.com/partdetail/C45000', 'GRM188R61A475KE15D': 'https://jlcpcb.com/partdetail/C71633', 'GRM188R71A225KE15D': 'https://jlcpcb.com/partdetail/C86018', 'GRM188R71H103KA01D': 'https://jlcpcb.com/partdetail/C77053', 'C0603C160J5GAC7867': 'https://jlcpcb.com/partdetail/C599683', 'RC0603FR-0710KL': 'https://jlcpcb.com/partdetail/C98220', 'RC0603FR-07100KL': 'https://jlcpcb.com/partdetail/C14675'}
def rows(path):return list(csv.DictReader(path.open()))
def write(path,h,items):
 with path.open('w',newline='') as f:
  w=csv.writer(f);w.writerow(h);w.writerows(items)
bom=rows(R/'assembly/kicad-bom.csv');pos=rows(R/'assembly/placements.csv');filtered=[x for x in bom if x['MPN']]
groups=collections.defaultdict(list)
for x in filtered:groups[x['MPN']].append(x)
assert set(groups)==set(CODES)
fitted={x['Reference'] for x in filtered};by={x['Ref']:x for x in pos if x['Ref'] in fitted};assert fitted==set(by)
write(R/'fabrication/jlc/BOM.csv',['Comment','Designator','Footprint','LCSC Part #'],[(v[0]['Value'],','.join(x['Reference'] for x in v),v[0]['Footprint'].split(':')[-1],CODES[k]) for k,v in groups.items()])
write(R/'fabrication/jlc/CPL.csv',['Designator','Mid X','Mid Y','Layer','Rotation'],[(r,x['PosX']+'mm',x['PosY']+'mm','Top',x['Rot']) for r,x in sorted(by.items())])
write(R/'assembly/procurement.csv',['MPN','Manufacturer','Value','Qty per PCB','Installed references','Manufacturer reference','LCSC part','JLC catalog'],[(k,v[0]['Manufacturer'],v[0]['Value'],len(v),', '.join(x['Reference'] for x in v),v[0]['Datasheet'],CODES[k],SUPPLIER_LINKS[k]) for k,v in groups.items()])
print(len(groups),'unique order lines;',len(fitted),'installed SMT components;',len(by),'centroids.')
