"""Read the vendor files, exported netlist and native routed board independently of the generator."""
from pathlib import Path
import xml.etree.ElementTree as ET
import csv,json,re,math,collections,hashlib,zipfile
import sexpdata as sx
r=Path(__file__).resolve().parents[1];d=r/'design'; ev=r/'evidence'
def subs(a,k):return [x for x in a if isinstance(x,list) and str(x[0])==k]
def sub(a,k):return subs(a,k)[0]
def show(x):return str(x[1])
board=sx.loads(next(d.glob('*.kicad_pcb')).read_text());fps={sub(x,'property')[2]:x for x in subs(board,'footprint')};xml=ET.parse(ev/'electrical.xml')
nets={n.get('name').lstrip('/'):{(x.get('ref'),x.get('pin')) for x in n.findall('node')} for n in xml.findall('.//nets/net')}
pairs={'SPI1_SCK':[('U1','21'),('U2','13')],'SPI1_MISO':[('U1','22'),('U2','1')],'SPI1_MOSI':[('U1','23'),('U2','14')],'IMU_CS':[('U1','20'),('U2','12'),('R4','2')],'IMU_INT1':[('U1','26'),('U2','4')],'CRSF_TX':[('U1','42'),('TP6','1')],'CRSF_RX':[('U1','43'),('TP7','1')],'SWDIO':[('U1','46'),('TP9','1')],'SWCLK':[('U1','49'),('TP10','1')],'NRST':[('U1','7'),('TP11','1')],'VBAT_1S':[('U3','1'),('U3','3'),('TP14','1')],'V3P0':[('U3','5'),('U1','1'),('U1','13'),('U1','19'),('U1','32'),('U1','48'),('U1','64'),('U2','5'),('U2','8')],'GND':[('U2','6'),('U2','7'),('U2','9'),('U1','12'),('U1','18'),('U1','63')], 'VCAP1':[('C7','1'),('U1','31')],'VCAP2':[('C8','1'),('U1','47')],'HSE_IN':[('U1','5'),('Y1','1'),('C14','1')],'HSE_OUT':[('U1','6'),('Y1','3'),('C15','1')],'VBAT_SENSE':[('U1','14'),('R5','2'),('R6','1')]}
for i,pin in enumerate([58,59,61,62],1):pairs['MOTOR'+str(i)]=[('U1',str(pin)),('TP'+str(i),'1')]
for n,points in pairs.items():
 assert set(points)<=nets[n],(n,points,nets[n])
 for ref,pad in points:
  padobj=next(p for p in subs(fps[ref],'pad') if str(p[1])==pad)
  assert str(sub(padobj,'net')[2])=='/'+n
netid={n[1]:str(n[2]).lstrip('/') for n in subs(board,'net')}
trace=collections.defaultdict(lambda:collections.Counter())
for s in subs(board,'segment'):
 n=netid[sub(s,'net')[1]];lay=sub(s,'layer')[1];a=sub(s,'start')[1:];b=sub(s,'end')[1:];trace[n][lay]+=math.dist(a,b)
vias=collections.Counter(netid[sub(s,'net')[1]] for s in subs(board,'via'))
for n in ('GND','V3P0'):assert vias[n]>1
for n in ('MOTOR1','MOTOR2','MOTOR3','MOTOR4','SPI1_SCK','SPI1_MISO','SPI1_MOSI','IMU_INT1'):assert sum(trace[n].values())>1
def dr(path):
 txt=path.read_text();return [tuple(map(float,t)) for t in re.findall(r'^X([-\d.]+)Y([-\d.]+)',txt,re.M)],re.findall(r'^T\d+C([\d.]+)',txt,re.M)
np,nd=dr(next((r/'fabrication/drill').glob('*-NPTH.drl')));pg,pd=dr(next((r/'fabrication/drill').glob('*-PTH.drl')))
assert nd==['3.000'] and pd==['0.300'];diags=sorted(math.dist(a,b) for i,a in enumerate(np) for b in np[i+1:]);assert len(np)==4 and all(abs(a-26)<.003 for a in diags[:4]);assert len(pg)==sum(vias.values())
outlines=[x for x in subs(board,'gr_line') if sub(x,'layer')[1]=='Edge.Cuts'];pts=[sub(a,'start')[1:] for a in outlines];span=[max(x[i] for x in pts)-min(x[i] for x in pts) for i in range(2)]
drc=json.loads((ev/'drc.json').read_text());erc=json.loads((ev/'erc.json').read_text());assert all(not drc[k] for k in ('violations','unconnected_items','schematic_parity')) and all(not s['violations'] for s in erc['sheets'])
with zipfile.ZipFile(r/'fabrication/Whoop-F405-A-Gerber-drill.zip') as f:
 gerbers=[k for k in f.namelist() if not k.endswith(('.drl','.gbrjob'))];assert len(gerbers)==10
 for k in gerbers:assert 'M02*' in f.read(k).decode()
bod=next((r/'fabrication/gerbers').glob('*.gbrjob'));job=json.loads(bod.read_text())
stack=sub(sub(board,'setup'),'stackup');assert abs(sum(float(sub(l,'thickness')[1]) for l in subs(stack,'layer') if subs(l,'thickness'))-.8)<.00001
report={'status':'pass','checked_native_nets':len(pairs),'copper_layers':[l[1] for l in sub(board,'layers')[1:] if str(l[1]).endswith('.Cu')],'board_thickness_mm':float(sub(sub(board,'general'),'thickness')[1]),'outline_xy_mm':span,'through_vias':sum(vias.values()),'via_diameter_mm':[.65,.30],'tracks':len(subs(board,'segment')),'npth_diameter_mm':float(nd[0]),'excellon_npth_xy_mm':np,'excellon_adjacent_mount_spacing_mm':diags[:4],'excellon_pth_count':len(pg),'gerber_layers_terminated':len(gerbers),'supply_and_ground_vias':{n:vias[n] for n in ('V3P0','GND')},'probed_nets':{n:{'pins':['.'.join(p) for p in pins],'routed_length_per_layer_mm':{l:round(a,3) for l,a in trace[n].items()},'through_vias':vias[n]} for n,pins in pairs.items()},'rule_violations':0,'unconnected':0,'schematic_parity':0,'erc':0, 'physical_tests':'none'}
(ev/'independent-readback.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ('probed_nets','excellon_npth_xy_mm')})
