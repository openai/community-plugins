#!/bin/sh
set -eu
cd "$(dirname "$0")"
clang --target=arm-none-eabi -mcpu=cortex-m4 -mthumb -ffreestanding -fno-builtin -Wall -Wextra -Werror -Os -g -fdebug-compilation-dir=. -ffile-prefix-map="$PWD"=. -c probe.c -o probe.o
if [ -n "${BENCH_RUST_LLD:-}" ]; then
 "$BENCH_RUST_LLD" -flavor gnu -T flash.ld probe.o -o whoop-bench-probe.elf
elif command -v ld.lld >/dev/null 2>&1; then
 ld.lld -T flash.ld probe.o -o whoop-bench-probe.elf
else
 rust_lld="$(rustc --print sysroot)/lib/rustlib/$(rustc -Vv | sed -n 's/^host: //p')/bin/rust-lld"
 "$rust_lld" -flavor gnu -T flash.ld probe.o -o whoop-bench-probe.elf
fi
