/* Board bring-up only. SWD supplies debug access; the aircraft cell powers the board.
 * Source references: ST RM0090 (RCC, GPIO, SPI) and TDK DS-000347 (register 0x75).
 * This program leaves PB6..PB9 as inputs with internal pulldowns throughout.
 */
typedef unsigned int u32;
typedef unsigned char u8;
#define REG(a) (*(volatile u32 *)(a))
#define RCC_CR REG(0x40023800)
#define RCC_AHB1ENR REG(0x40023830)
#define RCC_APB2ENR REG(0x40023844)
#define GPIOA_MODER REG(0x40020000)
#define GPIOA_BSRR REG(0x40020018)
#define GPIOA_AFRL REG(0x40020020)
#define GPIOB_MODER REG(0x40020400)
#define GPIOB_PUPDR REG(0x4002040C)
#define SPI1_CR1 REG(0x40013000)
#define SPI1_SR REG(0x40013008)
#define SPI1_DR (*(volatile u8 *)0x4001300C)

struct results {
    u32 signature, clock_ready, device_id, spi_timed_out, checks_complete, passed;
};
volatile struct results probe_results;
static u8 transfer(u8 tx) {
    u32 wait = 100000;
    while (!(SPI1_SR & 2) && --wait) {}
    if (!wait) { probe_results.spi_timed_out = 1; return 0; }
    SPI1_DR = tx;
    wait = 100000;
    while (!(SPI1_SR & 1) && --wait) {}
    if (!wait) { probe_results.spi_timed_out = 1; return 0; }
    return SPI1_DR;
}
static void halt(void) { for (;;) __asm__ volatile ("wfi"); }
void reset_handler(void) {
    /* The startup intentionally keeps the reset 16 MHz HSI system clock. */
    RCC_AHB1ENR |= 3; (void) RCC_AHB1ENR;
    GPIOB_MODER &= ~(0xffu << 12);
    GPIOB_PUPDR = (GPIOB_PUPDR & ~(0xffu << 12)) | (0xaau << 12);
    probe_results.signature = 0x57464341;
    probe_results.clock_ready = probe_results.device_id = probe_results.spi_timed_out = 0;
    probe_results.checks_complete = probe_results.passed = 0;
    RCC_CR |= 1u << 16;
    u32 wait = 1000000;
    while (!(RCC_CR & (1u << 17)) && --wait) {}
    probe_results.clock_ready = !!(RCC_CR & (1u << 17));
    /* CS stays high while enabling the SPI peripheral. AF5 on PA5..7. */
    GPIOA_BSRR = 1u << 4;
    GPIOA_AFRL = (GPIOA_AFRL & ~(0xfffu << 20)) | (0x555u << 20);
    GPIOA_MODER = (GPIOA_MODER & ~(0xffu << 8)) | (0xa9u << 8);
    RCC_APB2ENR |= 1u << 12; (void) RCC_APB2ENR;
    SPI1_CR1 = (1u<<9)|(1u<<8)|(1u<<6)|(5u<<3)|(1u<<2); /* mode 0, 250 kHz */
    for (volatile u32 delay=0; delay<250000; ++delay) {}
    GPIOA_BSRR = 1u << (16+4);
    transfer(0x80u | 0x75u);
    probe_results.device_id = transfer(0);
    wait = 100000;
    while ((SPI1_SR & 0x80) && --wait) {}
    if (!wait) probe_results.spi_timed_out = 1;
    GPIOA_BSRR = 1u << 4;
    probe_results.passed = probe_results.clock_ready && probe_results.device_id==0x47 && !probe_results.spi_timed_out;
    probe_results.checks_complete = 1;
    halt();
}
__attribute__((section(".vectors"),used))
const unsigned long vector_table[16] = {
    0x20020000, (unsigned long)reset_handler, (unsigned long)halt, (unsigned long)halt,
    (unsigned long)halt, (unsigned long)halt, (unsigned long)halt
};
