# Whoop F405 flight controller · Rev A

Open `design/Whoop-F405-A.kicad_pro` in KiCad 9.0.2 to edit the schematic or the routed board. This original primary controller hosts the STM32F405RGT6 processor and SPI-connected ICM-42688-P six-axis IMU. The design uses a separate 1S four-channel ESC, receiver and analog video system. The motor battery feed bypasses the controller. The two wires at the board’s battery input power its low-current electronics.

## Fabrication and assembly

| Deliverable | File |
|---|---|
| Fabricator input | [Four copper layers, masks, top paste, silks, profile and drills](fabrication/Whoop-F405-A-Gerber-drill.zip) |
| Assembly import | [JLC BOM](fabrication/jlc/BOM.csv) · [JLC top centroids](fabrication/jlc/CPL.csv) |
| Human-readable purchasing list | [11 MPNs and 26 fitted components](assembly/procurement.csv) |
| Searchable production documents | [Offline assembly guide](assembly-documents/assembly-guide.html) |
| Electrical drawing | [Schematic PDF](evidence/schematic.pdf) |
| Mechanical integration | [Populated STEP](assembly/Whoop-F405-A-mechanical.step) · [STEP with traces and pads](assembly/Whoop-F405-A-routed.step) |
| Visual inspection | [Populated native rendering](evidence/render/board-angled.png) · [Readback of actual fabrication files](evidence/render/fabrication-top.png) |
| Checked results | [Independent pin, drill and route readback](evidence/independent-readback.json) · [ERC](evidence/erc.json) · [DRC and schematic parity](evidence/drc.json) |

Specify 0.80 mm FR-4, four layers, 1 oz finished outer copper, nominal 0.5 oz internal copper, ENIG, green solder mask and single-sided top assembly. In1 is ground and In2 is 3.0 V. The shown prepreg/core values are design targets. Obtain the fabricator's compatible standard layup. The nominal profile measures 41.369553 mm across the mounting ears. Some CAM software includes the 0.05 mm plotting stroke and reports 41.419553 mm. Machine to the profile centerline. The four Ø3.00 mm unplated bores form a 26 mm square rotated 45°. There are 51 Ø0.30 mm plated via drills. The product includes 15 solder lands and no soldered headers. Pin 1 and each absolute rotation must be checked against the assembler’s actual part orientation in its placement preview before release.

## Wiring and bring-up

| Top land / native reference | Connection |
|---|---|
| TP1–TP4 | TIM4 CH1–4, PB6–PB9, logical motor commands 1–4 to the external ESC |
| TP5 | ESC logic ground |
| TP6 / TP7 / TP8 | UART1 TX to receiver RX, RX from receiver TX, common ground |
| TP9 / TP10 / TP11 / TP12 / TP13 | SWDIO, SWCLK, NRST, 3.0 V target-sense, ground |
| TP14 / TP15 | Single-cell positive, ground. Verify polarity before applying power. |

KiCad placement and fabrication use board-center XY, +X right and +Y up viewed from the component side. The mechanical STEP uses the same XY datum and the substrate begins at Z0. The underside legend maps the top solder points. TP12 is the regulated output and debugger reference. A separately powered receiver or video device requires a common ground and compatible logic levels. Keep any external 5 V supply away from V3P0 and the motor signal pads.

The always-enabled TLV75530PDBVR regulates the single cell to 3.0 V. The design targets a loaded battery of 3.3–4.2 V. At lower voltage or during motor transients the regulator may enter dropout. It provides no reverse-polarity or pack-short protection. Bench-test regulator temperature, dropout and brownout under the actual harness load. A 100 kΩ/100 kΩ divider feeds PA0 for battery sensing. Check ADC calibration. Two 2.2 µF capacitors support the separate MCU regulator VCAP pins. The 8 MHz YXC crystal has 12 pF specified load. Two 16 pF C0G parts imply 12 pF with 4 pF estimated effective stray. Measure margin and startup on the populated PCB.

The IMU runs on hardware SPI1. PA4 is chip select, PA5 is clock, PA6 is MISO and PA7 is MOSI. INT1 connects to PB0. The unused FSYNC input is grounded per TDK’s pin table. Firmware must leave INT2 output disabled. The reference direction of the IMU requires a six-face test on the mounted assembly before enabling flight control. The published register identity is 0x47. The optional [bench firmware](bench/README.md) probes that ID and oscillator readiness and leaves the four ESC outputs held low by internal pulldowns.

## Regenerate the release

In a new copy of this folder, use KiCad CLI **9.0.2** with its standard symbol/footprint libraries, Python 3 and a POSIX shell. The native PCB embeds its footprints. The project supplies the custom symbol/footprint libraries and all six mechanical STEP assets. Run from the copied folder:

```sh
kicad-cli version
sh tools/export.sh
python3 tools/readback.py
```

The script refuses export when electrical rules, layout rules, schematic parity or connectivity fail. Its output includes both STEP variants, the artwork/drill archive, assembly imports, editable layer graphics and source plots. File creation times and STEP serialization may change across builds. The [fresh rebuild comparison](evidence/source-rebuild.json) describes exactly which outputs were checked. Mechanical and electrical acceptance require a fabricated assembly, controlled props-off bring-up, verified ESC input thresholds and direction, and a board-specific flight firmware target with receiver failsafe and motor mapping. The digital handoff includes a bench-only probe. No order, unit, motor run or flight is recorded here.
