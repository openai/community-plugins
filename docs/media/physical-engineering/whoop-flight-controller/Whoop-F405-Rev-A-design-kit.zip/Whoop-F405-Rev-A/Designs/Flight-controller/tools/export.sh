#!/bin/sh
set -eu
case_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$case_dir"
name=Whoop-F405-A
b="design/$name.kicad_pcb"
s="design/$name.kicad_sch"
mkdir -p fabrication/gerbers fabrication/drill fabrication/jlc assembly evidence/plots
kicad-cli sch erc --severity-all --exit-code-violations --format json -o evidence/erc.json "$s"
kicad-cli pcb drc --all-track-errors --schematic-parity --severity-all --exit-code-violations --format json -o evidence/drc.json "$b"
kicad-cli sch export netlist --format kicadxml -o evidence/electrical.xml "$s"
kicad-cli sch export pdf -o evidence/schematic.pdf "$s"
kicad-cli sch export svg -o evidence/plots "$s"
kicad-cli pcb export gerbers -l F.Cu,In1.Cu,In2.Cu,B.Cu,F.Mask,B.Mask,F.Paste,F.Silkscreen,B.Silkscreen,Edge.Cuts --use-drill-file-origin -o fabrication/gerbers/ "$b"
kicad-cli pcb export drill --drill-origin plot --excellon-units mm --excellon-separate-th --generate-map --map-format pdf -o fabrication/drill/ "$b"
kicad-cli pcb export pos --units mm --format csv --use-drill-file-origin --smd-only -o assembly/placements.csv "$b"
kicad-cli sch export bom --fields 'Reference,Value,Footprint,MPN,Manufacturer,Datasheet' --labels 'Reference,Value,Footprint,MPN,Manufacturer,Datasheet' -o assembly/kicad-bom.csv "$s"
python3 tools/order_files.py
python3 - <<'PY'
from pathlib import Path
import zipfile
files=sorted(Path("fabrication/gerbers").glob("*"))+sorted(Path("fabrication/drill").glob("*.drl"))
with zipfile.ZipFile("fabrication/Whoop-F405-A-Gerber-drill.zip","w",compression=zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.name)
PY
kicad-cli pcb export step --force --grid-origin --cut-vias-in-body -o assembly/Whoop-F405-A-mechanical.step "$b"
kicad-cli pcb export step --force --grid-origin --include-pads --include-tracks --cut-vias-in-body -o assembly/Whoop-F405-A-routed.step "$b"
for layer in F.Cu In1.Cu In2.Cu B.Cu F.Silkscreen F.Paste Edge.Cuts; do
 kicad-cli pcb export svg --mode-single --fit-page-to-board --exclude-drawing-sheet -l "$layer" -o "evidence/plots/$layer.svg" "$b"
done
kicad-cli version > evidence/kicad-version.txt
