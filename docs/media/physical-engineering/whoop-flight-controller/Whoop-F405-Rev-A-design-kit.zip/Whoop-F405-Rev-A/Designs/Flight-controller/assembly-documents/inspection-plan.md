# Assembly inspection plan

Board: Whoop F405 flight controller; revision A; variant 1S-3V0-SPI; quantity 1.

1. Confirm the work order, board revision and variant with the responsible engineer.
2. Confirm material identity, availability, polarity, pin 1 and orientation against authoritative component and assembly documentation.
3. Compare populated references and placements with population.csv and placements.csv.
4. Independently review bottom-side orientation and machine-specific offsets before any production use.
5. Perform the electrical, process, soldering and inspection checks required by the responsible manufacturer.

This packet establishes document consistency only. Material availability, electrical qualification and manufacturing authorization are not established.
