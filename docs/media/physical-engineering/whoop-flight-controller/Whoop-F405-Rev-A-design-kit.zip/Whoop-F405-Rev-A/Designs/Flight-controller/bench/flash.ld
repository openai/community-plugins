ENTRY(reset_handler)
MEMORY { FLASH (rx) : ORIGIN = 0x08000000, LENGTH = 1024K
         RAM (rw) : ORIGIN = 0x20000000, LENGTH = 128K }
SECTIONS { .vectors : { KEEP(*(.vectors)) } >FLASH
 .text : { *(.text*) *(.rodata*) } >FLASH
 .ARM.exidx : { *(.ARM.exidx*) } >FLASH
 .bss (NOLOAD) : { *(.bss*) *(COMMON) } >RAM
}
