# Prepare a Mac for the Whoop rehearsal

The checked platform is Apple silicon macOS. Unzip the design kit and open Terminal in the folder containing `Designs` and `Presentation`. The offline aircraft viewer and released drawings open immediately. Prepare the following tools before a live rebuild.

## 1. Install the authoring plugins

For a fresh setup, install Codex Desktop, Codex CLI and Node.js 22.19 or later. Check that `codex plugin marketplace add --help` lists `--ref` and `--sparse`. The kit was reviewed with Codex CLI 0.144.3. [Codex Desktop](https://developers.openai.com/codex/app/) · [Codex CLI](https://developers.openai.com/codex/cli/) · [Node.js](https://nodejs.org/en/download)

These commands select the public revision containing Physical Engineering 0.3.0-preview.2 and PCBA Engineering 0.1.3. [Marketplace revision](https://github.com/tonyloehr/community-plugins/tree/4ae559565e4364680b7624660faa13d6f2069a1b)

```sh
codex --version
node --version
codex plugin marketplace add tonyloehr/community-plugins \
  --ref 4ae559565e4364680b7624660faa13d6f2069a1b \
  --sparse .agents/plugins --sparse plugins/physical-engineering --sparse plugins/pcba-engineering
codex plugin add physical-engineering@community-plugins
codex plugin add pcba-engineering@community-plugins
codex plugin list --marketplace community-plugins --json
```

Check that both plugins appear as installed and enabled at those versions. If you already use a marketplace named `community-plugins`, inspect its configured source and revision before changing it. The source kit’s exact Terminal rebuild can run independently of the Codex plugins. [Marketplace installation guide](https://github.com/tonyloehr/community-plugins/blob/4ae559565e4364680b7624660faa13d6f2069a1b/README.md)

## 2. Prepare the CAD runtime

Install uv and keep internet access on for the initial package download. This setup selects the reviewed Python patch and installs the kit’s exact CAD package list. The path is the plugin’s default, so a newly opened Desktop chat can find it. [Install uv](https://docs.astral.sh/uv/getting-started/installation/)

```sh
uv python install 3.14.6
WHOOP_CAD="$HOME/.cache/physical-engineering/runtime"
if [ ! -x "$WHOOP_CAD/bin/python" ]; then
  uv venv --python 3.14.6 "$WHOOP_CAD"
fi
"$WHOOP_CAD/bin/python" -c 'import sys; assert sys.version_info[:3] == (3, 14, 6), sys.version' && \
  "$WHOOP_CAD/bin/python" Designs/Aircraft/source/scripts/engineering.py setup --runtime "$WHOOP_CAD"
"$WHOOP_CAD/bin/python" -c 'from importlib.metadata import version; print({name: version(name) for name in ("cad", "build123d", "cadquery-ocp-novtk")})'
```

Expect Python 3.14.6, cad 0.10.3, build123d 0.13.0 and cadquery-ocp-novtk 8.0.1.1.0. If the Python check reports a different version in an existing environment, choose a new `WHOOP_CAD` path, repeat the setup and give Codex that absolute runtime path. For a shell replay, run `export PE_RUNTIME="$WHOOP_CAD"` and `export PATH="$WHOOP_CAD/bin:$PATH"` in the same Terminal session.

For interactive CAD in Desktop, review Text-to-CAD’s plan before applying it. The installer can replace an existing CAD integration and switch its running server. The first command displays the plan. If it matches the machine you intend to prepare, run the second and restart Codex Desktop. Select **Physical Engineering** and confirm **Text-to-CAD** is available in a new chat. [Text-to-CAD 0.10.3 setup](https://github.com/earthtojake/text-to-cad/blob/v0.10.3/docs/install.md)

```sh
"$WHOOP_CAD/bin/cad" setup --dry-run --only codex --no-telemetry
"$WHOOP_CAD/bin/cad" setup --only codex --no-telemetry
```

## 3. Build KiCad from the supplied Dockerfile

Start the Docker engine and run the following from the unpacked kit. Docker downloads Debian and the three version-pinned KiCad packages while building. Subsequent exports run with networking disabled. The runner uses the project’s bundled package models and libraries. [Docker Desktop for Mac](https://docs.docker.com/desktop/setup/install/mac-install/) · [Debian KiCad 9.0.2 package](https://packages.debian.org/trixie/kicad)

```sh
docker info --format '{{.OSType}}/{{.Architecture}}'
docker build --platform linux/arm64 -t physical-engineering-kicad:9.0.2 Designs/Runtime
docker run --rm --network none --entrypoint kicad-cli physical-engineering-kicad:9.0.2 version
```

The final command must print `9.0.2`. Use the new image to export the native board and run the independent checks.

```sh
sh Designs/Runtime/rebuild-flight-controller.sh Designs/Flight-controller Rehearsal/flight-controller
```

Open `Rehearsal/flight-controller/evidence/independent-readback.json`. The reviewed board has 22 named nets, 399 routed track segments and 51 vias, with zero open connections, ERC, DRC or schematic-parity violations. The runner requires a fresh destination each time. For visual editing in native KiCad, install 9.0.2 from the previous releases section. [KiCad for macOS](https://www.kicad.org/download/macos/) · [Board export instructions](../Flight-controller/README.md)

**Offline transfer.** For an offline Apple silicon presenter machine, build the image in advance and transfer it separately. On the prepared machine run `docker save -o physical-engineering-kicad-9.0.2.tar physical-engineering-kicad:9.0.2`. On the presenter machine run `docker load -i physical-engineering-kicad-9.0.2.tar`, then repeat the CLI version check above. Prepare the CAD environment before disconnecting as well.

The [setup verification receipt](../Evidence/release/runtime-bootstrap.json) records the public plugin installs, fresh CAD environment and board-image rebuild, including which steps ran in a clean container. Return to the [live prompts and exact aircraft replay](../../Presentation/Prompt-runbook.md).
