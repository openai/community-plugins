#!/bin/sh
# Rebuild a copied Whoop F405 design with local KiCad 9.0.2, without bind mounts.
set -eu
if [ "$#" -ne 2 ]; then
  printf '%s\n' "Usage: $0 FLIGHT_CONTROLLER_DIRECTORY NEW_OUTPUT_DIRECTORY" >&2
  exit 2
fi
source_dir=$(CDPATH= cd -- "$1" && pwd)
output=$2
if [ ! -f "$source_dir/design/Whoop-F405-A.kicad_pcb" ] || [ ! -f "$source_dir/tools/export.sh" ] || [ ! -f "$source_dir/tools/readback.py" ]; then
  printf '%s\n' "Expected design/ and tools/ in the supplied flight-controller release." >&2
  exit 2
fi
if [ -e "$output" ] || [ -L "$output" ]; then
  printf '%s\n' "Choose a new output directory. This path already exists: $output" >&2
  exit 2
fi
image=${KICAD_IMAGE:-physical-engineering-kicad:9.0.2}
docker image inspect "$image" >/dev/null
container=$(docker create --network none --entrypoint /bin/sh "$image" -c '
  set -eu
  newdir=$(mktemp -d /tmp/whoop-rebuild.XXXXXXXX)
  mv /tmp/whoop-source-design "$newdir/design"
  mv /tmp/whoop-source-tools "$newdir/tools"
  cd "$newdir"
  actual=$(kicad-cli version)
  if [ "$actual" != 9.0.2 ]; then
    printf "%s\n" "Expected KiCad 9.0.2. This image reports $actual." >&2
    exit 1
  fi
  sh tools/export.sh
  python3 tools/readback.py
  printf "%s" "$newdir" >/tmp/whoop-result-location
')
cleanup() { docker rm -f "$container" >/dev/null 2>&1 || true; }
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
docker cp "$source_dir/design" "$container:/tmp/whoop-source-design"
docker cp "$source_dir/tools" "$container:/tmp/whoop-source-tools"
docker start -a "$container"
status=$(docker inspect --format '{{.State.ExitCode}}' "$container")
[ "$status" = 0 ] || exit "$status"
# A stopped container cannot execute a command. Use Docker's tar stream for its result pointer.
result=$(docker cp "$container:/tmp/whoop-result-location" - | tar -xOf -)
case "$result" in /tmp/whoop-rebuild.*) ;; *) printf '%s\n' 'Unexpected build result path.' >&2; exit 1 ;; esac
mkdir -p "$(dirname "$output")"
mkdir "$output"
docker cp "$container:$result/." "$output"
printf 'Verified fabrication package and readback are in %s\n' "$output"
