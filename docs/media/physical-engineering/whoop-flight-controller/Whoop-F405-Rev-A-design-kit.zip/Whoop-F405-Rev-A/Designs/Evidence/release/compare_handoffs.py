"""Compare both independently rebuilt readbacks, including STEP exports whose timestamp headers change."""
from pathlib import Path
import sys,json,hashlib,csv
base,other,out=map(Path,sys.argv[1:4]);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p,n):return json.loads((p/n).read_text())
ma,mb=load(base,'manifest.json'),load(other,'manifest.json')
assert mb['reproduction']['status']=='pass' and mb['reproduction']['baseline_manifest_sha256']==h(base/'manifest.json')
a,b=load(base,'stack-fit.json'),load(other,'stack-fit.json');assert a['verified'] and b['verified'] and a['checks']==b['checks'] and a['measurements']==b['measurements']
g,gg=load(base,'guard-wall.json'),load(other,'guard-wall.json');assert g==gg and g['status']=='pass'
m,mm=load(base,'measurements.json'),load(other,'measurements.json');assert m['checks']==mm['checks'] and m['status']=='pass'
for k in ['assembly.glb','viewer.html','preview.png','bom.csv','bom.xlsx']:assert h(base/k)==h(other/k)
source='source/design/geometry/inputs/Whoop-F405-A.step'
purch=list(csv.DictReader((base/'source/design/boards/aircraft-bom.csv').open()));installed=list(csv.DictReader((base/'bom.csv').open()));q=lambda rows:{r['ID']:r['Qty'] for r in rows if r['Scope']=='Aircraft'}
assert q(installed)==q(purch);ids={i['ID'] for i in purch if i['Scope']=='Board placement'};qty=sum(int(i['Qty']) for i in purch if i['Scope']=='Board placement')
report={'status':'pass','design':ma['design'],'generic_checks':len(m['checks']),'supplemental_stack_checks':len(a['checks']),'guard_rims':len(g['actual']['rings']),'aircraft_ids_reconciled_with_procurement':len(q(purch)),'board_placement_lines':len(ids),'fitted_reference_quantity':qty,'source_pcba_step_sha256':h(base/source),'assembly_glb_sha256':h(base/'assembly.glb'),'baseline_manifest_sha256':h(base/'manifest.json'),'clean_rebuild_manifest_sha256':h(other/'manifest.json'),'compared':mb['reproduction']['compared']+['52 supplemental stack checks and measured values','four guard bores and walls','32 aircraft BOM line quantities against the purchasing workbook']}
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
