# Mechanical verification evidence

The installed release has three reports: measurements.json covers the plugin's declared geometry, ownership and BOM checks; guard-wall.json reads four guard bores and radial wall thicknesses; stack-fit.json checks the real flight-controller mounting holes, nominal purchased module allowances, frame/sled continuity, screw interfaces, conservative rotor envelopes and 2 mm raised-dock counterexample. Use the corresponding handoff STEP and GLB for the accepted model.

- **dock-lift/** contains the exported accepted and raised docks, the four full-diameter static gauges and the two actual positive-volume common solids. The readback records 4.56 mm³ combined over both rear rotors. In the normal installed position the minimum positive distance is 1.79 mm.
- **canopy/** preserves the coarse original failed mesh readback and its corrected finer export. The surface match remains at 0.10 mm in both checks.
- **rail-candidate.json** is the first assembly candidate's independent STEP readback before the lower pocket rails moved outward 0.15 mm. Three modules failed the 0.35 mm body-to-sled requirement at 0.25 mm. Apply rail-rejection.patch to a copy of source/design to replay the old 0.25 mm drawings and observe rejection. That candidate used the placement-stage flight board. The final release uses its routed mechanical STEP and seats all three modules on 0.35 mm pads with 0.40 mm nominal clearance to those rails.
- **release/reproduction.json** compares both verified handoffs, case-specific readbacks, color/mesh artifacts, procurement quantities and in-recipe STEP input. The standard rebuild compares the same editable inputs and the exact GLB, preview, viewer, print files and workbook. STEP transfer timestamps may differ.

The release also passed [offline desktop and phone viewer checks](release/offline-viewer.json) and [a repeatable model-color check](release/viewer-colors.json). The offline KiCad replay reads 399 routed segments, 51 through vias and 22 native nets. [Offline board readback](release/offline-board-readback.json)

These records establish digital geometric fit of the stated bodies and allocations. The actual ESC thickness, soldered harness, whip routing, thermal behavior, 1S current budget and flight remain physical acceptance gates.

The approved GLB has 124 named meshes, with maximum bounding-box deviation of 0.0079 mm against individual STEP occurrences. The four printed meshes each form one closed, consistently wound solid. CAD solid volumes are 5,221.305 mm³ for the revised frame and 1,641.940 mm³ for the removable sled; these are geometric material volumes, not measured printed masses. The underside ESC posts and accessory shelf overhangs need actual slicer support and a printed trial.
