"""Construct the actual rejected CAD witness for a 2 mm dock lift against the conservative prop gauges."""
from pathlib import Path
import math,json,sys,copy,build123d as bd
root=Path(__file__).resolve().parent.parent
p=Path(sys.argv[1]);o=Path(sys.argv[2]);o.mkdir(parents=True,exist_ok=True)
base=bd.import_step(p/'components/dock.step');scene=bd.import_step(p/'assembly.step')
motors=[z for z in scene.children if z.label.startswith('propulsion_')];d=65/math.sqrt(8)
prop=next(n for n in motors[0].descendants if n.label and n.label.startswith('prop_'))
b=prop.bounding_box();s=bd.Compound(children=[bd.Solid.make_cylinder(15.5,b.max.Z-b.min.Z,bd.Plane(origin=(x*d,y*d,b.min.Z))) for x in (-1,1) for y in (-1,1)])
new=bd.Pos(0,0,2)*base;overlap=new.intersect(s);solids=list(overlap.solids()) if hasattr(overlap,'solids') else list(overlap)
for obj,n in [(base,'accepted-dock'),(new,'rejected-dock-plus-2mm'),(s,'four-prop-swept-gauges')]:bd.export_step(obj,o/(n+'.step'))
common=bd.Compound(children=solids,label='Positive_volume_overlap');bd.export_step(common,o/'rejected-interference.step')
report={'method':'OCCT exported dock and rotor BRep. Four full swept cylindrical gauges, each 31 mm diameter across blade vertical extent. Design alternatives use the same camera/dock geometry.','nominal_clearance_mm':round(base.distance_to(s),5),'raised_dock_mm':2.,'overlap_mm3':round(sum(q.volume for q in solids),5),'overlap_regions':[{'volume_mm3':round(q.volume,6),'center_mm':[round(v,4) for v in q.center()],'bounds_mm':[[round(x,4) for x in v] for v in (q.bounding_box().min,q.bounding_box().max)]} for q in solids]};(o/'readback.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
