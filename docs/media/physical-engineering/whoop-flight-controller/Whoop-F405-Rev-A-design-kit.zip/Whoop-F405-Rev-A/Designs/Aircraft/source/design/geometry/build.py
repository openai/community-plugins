"""Build the 65 mm Whoop from its editable stock geometry, split-stage changes and original KiCad export."""
from pathlib import Path
import collections,copy,sys,struct,json
import build123d as bd
sys.dont_write_bytecode=True
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here/'base'))
import frame,hardware,snap,check_guard_wall,cradle,inspect_stack
def detached(shape):
 s=copy.copy(shape);s.parent=None;return s
def print_file(s,p):
 cradle.write_print(s,p)
 data=bytearray(p.read_bytes());n=struct.unpack_from('<I',data,80)[0]
 for i in range(n):
  for off in (20,32,44):
   offset=84+i*50+off
   if abs(struct.unpack_from('<f',data,offset)[0])<1e-7:struct.pack_into('<f',data,offset,0.)
 p.write_bytes(data)
def unique_labels(s):
 counts=collections.Counter(x.label for x in s.children);seen=collections.Counter()
 for p in s.children:
  label=p.label
  if counts[label]>1:
   seen[label]+=1;p.label=f'{label}_{seen[label]:02}'
  unique_labels(p)
def apply_board_finishes(board):
 # A KiCad STEP package often carries several face colors. Reapply the reviewed
 # display finish to each named package leaf so viewer bytes are repeatable.
 from OCP.Quantity import Quantity_Color,Quantity_ColorRGBA,Quantity_TypeOfColor
 palette=json.loads((here/'inputs/pcb-finishes.json').read_text())['colors']
 for leaf in board.leaves:
  red,green,blue,alpha=palette[leaf.label]
  linear=Quantity_Color(red,green,blue,Quantity_TypeOfColor.Quantity_TOC_RGB)
  leaf.color=bd.Color(Quantity_ColorRGBA(linear,alpha))
def named(part,name):
 part.label=name;return part
def nodes(part,parent=None,path=''):
 loc=(bd.Location() if parent is None else parent)*part.location
 key=(path+'/'+part.label) if path else part.label
 yield key,part.located(loc)
 for child in part.children:yield from nodes(child,loc,key)
def file_for(path):
 name=path.split('/')[-1]
 simple={'whoop_frame_with_ESC_posts':'frame','removable_battery_sled':'battery-sled','snap_canopy':'canopy','snap_dock':'dock','fpv_camera':'fpv-camera','HAKRC_HK10AX4_admission_envelope':'esc-fit-envelope','Whoop_F405_Rev_A':'flight-controller','battery_pack_in_sled':'battery-installed','BETAFPV_ELRS_Lite_Flat_1_2_fit_envelope':'receiver-fit-envelope','TBS_UNIFY_PRO32_Nano_fit_envelope':'vtx-fit-envelope','Pololu_U3V16F5_no_headers_fit_envelope':'boost-fit-envelope'}
 if name in simple:return simple[name]
 if name in ('motor_FL','motor_FR','motor_RL','motor_RR') or name.startswith('prop_'):return name.replace('_','-')
 return None
def build(out):
 import json
 (out/'components').mkdir(exist_ok=True,parents=True);(out/'print').mkdir(exist_ok=True)
 framepart,sled,esc,radios,tapes,eh,sh=cradle.stack(frame.component())
 dock=snap.clip_dock();dock.color='#31A598';can=snap.clip_canopy(hardware.canopy())
 battery=named(bd.Pos(0,0,cradle.SLED_TOP)*hardware.battery_pack(),'battery_pack_in_sled')
 straps=named(bd.Pos(0,0,cradle.SLED_TOP)*hardware.battery_retention(),'battery_straps_and_pads')
 fc=named(bd.Pos(0,0,3.50)*bd.import_step(here/'inputs/Whoop-F405-A.step'),'Whoop_F405_Rev_A');unique_labels(fc);apply_board_finishes(fc)
 parts=[framepart,sled,esc,radios,tapes,eh,sh,battery,straps,dock,can,*hardware.propulsion(),hardware.fpv_camera(),hardware.stack_hardware(),fc]
 for n,q in [('frame',framepart),('battery-sled',sled),('canopy',can),('dock',dock)]:print_file(q,out/'print'/(n+'.stl'))
 # Auxiliary coupons are bench tooling. The declared installed-part verifier owns print/; retain these in a separate bench folder.
 (out/'bench').mkdir(exist_ok=True)
 for n,q in zip(('coupon-spring','coupon-catch'),snap.coupons()):print_file(q,out/'bench'/(n+'.stl'))
 scene=bd.Compound(children=parts,label='Whoop65_F405_Rev_A')
 for path,shape in nodes(scene):
  file=file_for(path)
  if file:bd.export_step(detached(shape),out/'components'/(file+'.step'))
 bd.export_step(scene,out/'assembly.step')
 bd.export_gltf(scene,out/'assembly.glb',binary=True,linear_deflection=.055,angular_deflection=.19)
 if not check_guard_wall.inspect(out/'components/frame.step',out/'guard-wall.json'):raise ValueError('Guard bore/wall drawing is violated')
 if not inspect_stack.export_report(out,out/'stack-fit.json'):raise ValueError('Read stack-fit.json; installed solid check failed')
if __name__=='__main__':build(Path(sys.argv[1]))
