# Whoop F405 Rev A board interfaces

The custom flight controller replaces the purchased integrated board. It carries the STM32F405 controller, ICM-42688-P inertial sensor and its own 3.0 V supply. The ESC, 5 V boost, receiver and analog video transmitter are separate purchased boards. The complete aircraft remains a fabrication candidate. Flight firmware, closed-loop control, RF, bench power and actual assembly have yet to be qualified.

## Installed coordinate system

The origin lies beneath the flight controller, at the center of the four 65 mm-diagonal motor axes. Z points upward and the camera looks toward +Y. All component STEP files use this datum. Print STLs use local, centered, bed-level coordinates. The source PCB STEP uses its own centered XY datum and moves +3.50 mm in Z to install. The substrate material in the KiCad reference export spans 0.710 mm, while the board's fabrication target is 0.800 mm. Copper/finish contribution varies by exporter and site; use fabricated board calipers to qualify grommet shoulder fit.

| Board | Mechanical basis and placement | Electrical integration |
| --- | --- | --- |
| Whoop F405 Rev A | Actual populated native KiCad export. Four Ø3.00 mm grommet holes on the cardinal axes at ±18.3848 mm. 26 fitted devices. Four compressed rubber grommets and screws share the original mounting drawing. | 1S VBAT to the onboard 3.0 V regulator, four motor signal outputs and common ground to ESC, receiver UART, SWD for programming. Use the accompanying editable electronics project for net names, pin identities and source BOM. |
| HAKRC HK10AX4 | 20 × 22 mm vendor footprint, four M2 holes on 16 × 16 mm centers. Total installed Z allocation is 4.00 mm, from −6.90 to −2.90. The 1.00 mm central substrate and Ø4.60 mm local component exclusion around screws are design assumptions. Confirm actual height on both sides, substrate thickness, hole size, copper isolation and fastening. [Supplier drawing and ratings](https://flexrc.com/product/hakrc-10a-1-2s-16x16/) | Shared battery rail and ground; separate 1–2S LiHV 4-in-1 BLHeli_S, quoted 10 A continuous per channel. Digital input thresholds, completed motor-pad wiring and operation with this 3.0 V controller await measurement. |
| BETAFPV ELRS Lite Flat V1.2 | Manufacturer envelope 11 × 10 × 3 mm. Right-hand forward pocket, integral antenna; check RF performance and keepout. [BETAFPV dimensions](https://betafpv.com/products/elrs-lite-receiver) | Regulated 5 V, ground and crossed serial TX/RX. |
| TBS UNIFY PRO32 Nano V1.1 | Left-hand pocket, published 15 × 13 × 2 mm; CAD reserves 3.00 mm total height. The antenna whip and lead bending envelope require hardware. [TBS specifications](https://www.team-blacksheep.com/products/prod:unifypro32_nano) | Proposed regulated 5 V from the boost, common ground and C03 composite video input. External whip uses the supplied u.FL lead. |
| Pololu U3V16F5, #4941 | Right-hand rear pocket, published 0.32 × 0.52 × 0.1 in equals 8.128 × 13.208 × 2.54 mm, excluding optional headers. [Pololu dimensions](https://www.pololu.com/product/4941/specs) | 1S to regulated 5 V for the receiver, camera and VTX. Verify actual combined continuous load, input sag and ripple, particularly at VTX power settings. |
| BETAFPV C03 camera | The original camera/canopy mechanical reference is retained in the anterior snap dock. CAD represents external features. [C03 product drawing](https://betafpv.com/products/c03-fpv-micro-camera) | Regulated supply, common ground, analog video to the external transmitter. Check actual harness conductor order. |

## Motor-stage selection

The motor manufacturer's GF1219S + 0702SE II 27000KV chart gives 5.20 A at 4.0 V/full throttle. The smaller 4.3 A-continuous, 5 A-burst tinyPEPPER candidate falls below this observation. The design reserves the HAKRC 10 A continuous stage. The bench dataset does not establish loaded current at a fresh 4.35 V charge or completed aircraft thermal performance. [BETAFPV measured motor data](https://betafpv.com/cdn/shop/files/0702SE_II_a61328e2-6ca0-48d7-839d-d9772115362c.jpg?v=1735612938) · [HAKRC model specifications](https://ticofpv.com/collections/loyalty-points/products/hakrc-hk10ax4-blheli_s-10a-1-2s-4-in-1)

## Service and physical checks

Four M2 × 8 nominal screws clamp the motor-stage reference against printed posts, with four captured M2 AF4 nuts. The four smaller top-access sled screws enter printed pilots and provide a removable undercarriage. Their pilot/thread engagement is intentional. The two original loops and compliant pads retain the 54 × 11 × 6.5 mm battery on the underside of the new sled. Its bottom and the separate board pockets change mass distribution and ground clearance. Three nominal 0.35 mm adhesive pads seat the separate RF/boost envelopes. The pocket rails preserve at least 0.35 mm nominal free space to those board bodies.

Check printed dimensions, pocket retention, grommet compression, the physical battery, ESC case and hardware before powering the system. Weigh and balance the completed assembly. Verify harness polarity, actual wiring routes, strain relief, VTX antenna clearance and supplied component current/thermal limits. The inspection uses rigid static CAD and conservative propeller swept-volume gauges. It supplies no vibration, RF, impact, endurance, hover or flight measurements.

## Procurement and board fabrication

The integrated aircraft and procurement workbook share 32 installed BOM IDs, including the receiver's integral ceramic antenna and three distinct wiring groups. The original PCBA counts once at aircraft level; its four-layer, 0.80 mm nominal ENIG board and its 26 fitted devices appear as child lines in the procurement workbook. The pre-existing BT2.0 pigtail is rated 9 A continuous/15 A burst, while four independent manufacturer motor test points sum to 20.8 A before accessories at 4.0 V. This is an outstanding system-level current constraint. Validate or redesign the power interconnect and battery choice before sustained motor testing.

[Aircraft and child PCBA purchasing workbook](source/design/boards/aircraft-bom.xlsx) · [Assembly BOM with manufacturer part numbers](source/design/boards/board-assembly-bom.csv) · [Procurement and power budget](source/design/boards/fabrication-and-procurement.md)
