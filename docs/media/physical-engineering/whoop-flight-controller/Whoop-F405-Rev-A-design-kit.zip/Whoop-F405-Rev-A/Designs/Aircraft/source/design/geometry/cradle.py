"""Build the printable lower electronics cradle for the existing 65 mm quad. Dimensions are millimeters."""
import argparse,json,math,hashlib,sys,copy
from pathlib import Path
import build123d as bd

root=Path(__file__).resolve().parents[1]
# Aircraft datums use stock X left/right, Y front/back and Z up. The original FC and camera retain their installed planes.
MOUNT=[(x,y) for x in (-8.,8.) for y in (-8.,8.)]
SLED=[(x,y) for x in (-14.,14.) for y in (-8.5,8.5)]
STOCK_BOTTOM=-1.25
PCB_TOP=-4.40
PCB_BOTTOM=-5.40   # unverified COTS substrate assumption, subject to sample/washer adjustment
ENVELOPE_BOTTOM=-6.90
ENVELOPE_TOP=-2.90
SLED_TOP=-8.20
SLED_BOTTOM=SLED_TOP-1.25
def extrude(x,y,sketch,z0,z1):return bd.Pos(x,y,z0)*bd.extrude(sketch,amount=z1-z0)
def cyl(x,y,r,z0,z1):return bd.Solid.make_cylinder(r,z1-z0,bd.Plane(origin=(x,y,z0)))
def rect(x,y,dx,dy,rad,z0,z1):return extrude(x,y,bd.RectangleRounded(dx,dy,rad),z0,z1)
def hexagon(x,y,af,z0,z1):return extrude(x,y,bd.RegularPolygon(af/math.sqrt(3),6),z0,z1)
def name(s,label,col):s.label=label;s.color=col;return s
def one(s,label):
 if len(s.solids())!=1 or not s.is_valid:raise ValueError(label+' is not a single valid solid')
 return s.solids()[0]
def raw_volume(s):
 if s is None:return 0.
 if isinstance(s,(list,tuple)):return sum(o.volume for o in s)
 return s.volume
def overlap(a,b):return round(raw_volume(a.intersect(b)),7)
def hash_file(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def screws(x,y,od,zhead0,zhead1,shaft_r,ztip,seat,nameprefix,upward=False):
 head=cyl(x,y,od/2,zhead0,zhead1)
 head=head.cut(hexagon(x,y,1.4 if od>3 else .9,zhead0-.02,zhead0+.55) if upward else hexagon(x,y,.9,zhead1-.38,zhead1+.02))
 neck=cyl(x,y,shaft_r,min(ztip,seat),max(ztip,seat))
 return name(head.fuse(neck),nameprefix,'#78848A')
RADIOS=[("TBS_UNIFY_PRO32_Nano_fit_envelope",-16.25,0,15,13,3.0,"#6688A7"),("BETAFPV_ELRS_Lite_Flat_1_2_fit_envelope",15.75,7.55,11,10,3.0,"#819765"),("Pololu_U3V16F5_no_headers_fit_envelope",15.75,-6.50,8.128,13.208,2.54,"#987B62")]
SHELF_TOP=-13.75
TAPE=.35
def auxiliary(lc):
 parts=[];tapes=[]
 for key,x,y,dx,dy,dz,color in RADIOS:
  b=bd.Pos(x,y,SHELF_TOP+TAPE+dz/2)*bd.Box(dx,dy,dz)
  parts.append(name(b,key,color))
  tape=bd.Pos(x,y,SHELF_TOP+TAPE/2)*bd.Box(dx-2,dy-2,TAPE);tapes.append(name(tape,key+'_mounting_pad','#829393'))
  # Open top and both cable-access ends. Two small side rails set lateral placement.
  lc.append(rect(x,y,dx+3.,dy+1.4,1.0,SHELF_TOP-.90,SHELF_TOP))
  for side in (-1,1):
   lc.append(rect(x+side*(dx/2+.90),y,1.,dy*.62,.35,SHELF_TOP-.08,SHELF_TOP+1.15))
  # Two perforation-free uprights outside the equipment envelope tie the lower shelf to the existing sled.
  inner=x-math.copysign(dx/2+1.15,x)
  for yy in [y-dy*.32,y+dy*.32]:
   lc.append(rect(inner,yy,1.4,2.1,.5,SHELF_TOP-.10,SLED_BOTTOM+.20))
   # Top bridge at sled underside, installed components remain below it.
   inner_rail=math.copysign(14.,x);lo,hi=sorted([inner,inner_rail])
   lc.append(rect((hi+lo)/2,yy,hi-lo+1.5,2.1,.5,SLED_BOTTOM-.35,SLED_TOP))
 return bd.Compound(children=parts,label='FPV_radio_and_boost_envelopes'),bd.Compound(children=tapes,label='module_adhesive_pads')
def stack(frame):
 extras,cuts=[],[]
 # Refuse the old battery strap slots: this load path becomes the motor-stage bracket. Relocate the original two strap loops to the sled.
 for y in (-8.5,8.5):
  extras.append(rect(0,y,22.6,7.4,1.7,STOCK_BOTTOM,0))
 for x,y in SLED:
  extras.append(rect(math.copysign(11.75,x),y,9.,4.8,1.85,STOCK_BOTTOM,0))
  cuts.append(cyl(x,y,.80,STOCK_BOTTOM-.04,.04))
 for x,y in MOUNT:
  extras.append(cyl(x,y,1.90,PCB_TOP,-1.10))
  extras.append(hexagon(x,y,5.5,-.10,1.43))
  cuts+=[cyl(x,y,1.10,PCB_TOP-.05,1.46),hexagon(x,y,4.16,0,1.50)]
 revised=one(frame.fuse(*extras).cut(*cuts).clean(),'Frame')
 revised=name(revised,'whoop_frame_with_ESC_posts','#243746')
 # Sled is removed downward after releasing the four top-access 1.4 mm screws. The wider side rails avoid the entire ESC XY envelope.
 lc=[rect(0,y,32.,7.4,1.8,SLED_BOTTOM,SLED_TOP) for y in (-8.5,8.5)]
 lc += [rect(x,0,3.8,20.3,1.5,SLED_BOTTOM,SLED_TOP) for x in (-14.,14.)]
 cut=[]
 for x,y in SLED:
  lc.append(cyl(x,y,1.95,SLED_TOP-.12,STOCK_BOTTOM));cut.append(cyl(x,y,.625,STOCK_BOTTOM-3.3,STOCK_BOTTOM+.08))
 for x in (-7.6,7.6):
  for y in (-8.5,8.5):cut.append(rect(x,y,2,4.8,.45,SLED_BOTTOM-.05,SLED_TOP+.05))
 radios,tapes=auxiliary(lc)
 sled=name(one(lc[0].fuse(*lc[1:]).cut(*cut).clean(),'Sled'),'removable_battery_sled','#EB843F')
 # Board overall width/length and four M2 axes are vendor-published. Z portions are explicitly an allocated fit envelope.
 board=bd.Pos(0,0,(PCB_TOP+PCB_BOTTOM)/2)*bd.Box(20,22,PCB_TOP-PCB_BOTTOM)
 top=bd.Pos(0,0,(PCB_TOP+ENVELOPE_TOP)/2)*bd.Box(20,22,ENVELOPE_TOP-PCB_TOP)
 low=bd.Pos(0,0,(PCB_BOTTOM+ENVELOPE_BOTTOM)/2)*bd.Box(20,22,PCB_BOTTOM-ENVELOPE_BOTTOM)
 for x,y in MOUNT:
  board=board.cut(cyl(x,y,1.0,PCB_BOTTOM-.01,PCB_TOP+.01))
  top=top.cut(cyl(x,y,2.30,PCB_TOP-.01,ENVELOPE_TOP+.01));low=low.cut(cyl(x,y,2.30,ENVELOPE_BOTTOM-.01,PCB_BOTTOM+.01))
 board=name(board,'ESC_nominal_substrate_assumption','#427868')
 esc=bd.Compound(children=[board,name(top,'ESC_upper_height_allowance','#839D90'),name(low,'ESC_lower_height_allowance','#839D90')],label='HAKRC_HK10AX4_admission_envelope')
 hw=[];shelf_hw=[]
 for k,(x,y) in enumerate(MOUNT,1):
  # ISO 4032 M2 reference nut, 4.0 AF x 1.6 nominal. Thread engagement in the nut is represented by coincident bores.
  nut=hexagon(x,y,4.,.0,1.60).cut(cyl(x,y,1.,-.04,1.65))
  hw.extend([name(nut,f'ESC_nut_{k}','#7E8C93'),screws(x,y,3.8,PCB_BOTTOM-1.35,PCB_BOTTOM,1.,PCB_BOTTOM+8,PCB_BOTTOM,f'ESC_M2x8_{k}',True)])
 for k,(x,y) in enumerate(SLED,1):
  shelf_hw.append(screws(x,y,2.44,0,.65,.67,-4.,0,f'sled_ST1_4x4_{k}'))
 return revised,sled,esc,radios,tapes,bd.Compound(children=hw,label='ESC_mount_hardware'),bd.Compound(children=shelf_hw,label='sled_mount_hardware')
def write_print(shape,path):
 b=shape.bounding_box();m=bd.Pos(-(b.max.X+b.min.X)/2,-(b.max.Y+b.min.Y)/2,-b.min.Z)*shape
 linear, angular = (.015,.12) if path.stem == 'frame' else (.018,.11)
 if not bd.export_stl(m,path,tolerance=linear,angular_tolerance=angular):raise RuntimeError(path)
