# Whoop 65 with custom F405 controller

Open viewer.html to rotate the aircraft, inspect its underside or explode the electronics stack. The flight-controller view isolates the actual populated custom KiCad assembly. The four rectangular purchased electronic modules are documented fit envelopes. The external camera, motors, rotor shapes, pack and fasteners use existing reference geometry. Work from the enclosed project and board guide before fabricating.

- **Editable geometry** lives in source/design/geometry. Base frame, props, motors, camera cradle and snap geometry are parametric. cradle.py defines the four ESC mounts and removable battery/RF sled. build.py positions the populated STEP from the companion native electronics project.
- **Print** the frame, dock, canopy and battery/RF sled in print/. Find latch coupons in bench/. Slicer supports, material, thread grip and final mass require physical qualification.
- **Source** installed parts from bom.xlsx or bom.csv. Use the companion native electronics fabrication BOM for the devices on the one custom flight-controller assembly.
- **Measure** with measurements.json (plugin declared assembly checks), guard-wall.json (four guard bores/walls) and stack-fit.json (added board, pocket, battery and rotor interference checks). An independent 2 mm dock-lift negative control demonstrates why the motor stage moved below the frame.
- **Rebuild** with rebuild.sh in a fresh output directory using the pinned CAD runtime. Every CAD input needed for this handoff is inside source/. Independent electronics edits must be re-exported to source/design/geometry/inputs/Whoop-F405-A.step.

This is a digital engineering study. No assembled, powered or flown hardware is claimed. The installed HAKRC reference uses a purchaser-measured height gate; the nominal 4.00 mm allocation and mounting-zone clearances still require a sample. Release of a flying aircraft additionally needs ESC/FC signal-level checks, closed-loop flight firmware, RF/5 V verification, real harnesses, prop balance and mass/flight tests.
