"""Read installed solids, independent of generator code and upstream in-memory objects."""
from pathlib import Path
import argparse,hashlib,json,math,functools
import build123d as bd
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Cylinder
from OCP.TopAbs import TopAbs_REVERSED

def bb(part):
 b=part.bounding_box();return [[round(v,5) for v in q] for q in (b.min,b.max)]
@functools.lru_cache(maxsize=None)
def solid_boxes(p):
 return [(x,bb(x)) for x in p.solids()]
def pairs(a,b):
 out=[]
 for x,(lo,hi) in solid_boxes(a):
  for y,(lo2,hi2) in solid_boxes(b):
   g=[max(0.,lo2[i]-hi[i],lo[i]-hi2[i]) for i in range(3)]
   out.append((math.sqrt(sum(q*q for q in g)),x,y))
 return sorted(out,key=lambda e:e[0])
def dist(a,b):
 best=float('inf')
 for lower,x,y in pairs(a,b):
  if lower>best+.0001:break
  best=min(best,x.distance_to(y))
  if best<1e-7:break
 return round(best,5)
def overlap(a,b):
 volume=0.
 for gap,x,y in pairs(a,b):
  if gap>.0001:break
  v=x.intersect(y)
  if v:volume+=sum(s.volume for s in v) if isinstance(v,(list,tuple)) else v.volume
 return round(volume,5)
def axes(part,r):
 out=set()
 for f in part.faces():
  a=BRepAdaptor_Surface(f.wrapped)
  if a.GetType()!=GeomAbs_Cylinder or f.wrapped.Orientation()!=TopAbs_REVERSED:continue
  c=a.Cylinder()
  if abs(c.Radius()-r)>.001 or abs(c.Axis().Direction().Z())<.99999:continue
  out.add(tuple(round(n,4) for n in c.Axis().Location().Coord()[:2]))
 return sorted(out)
def fingerprint(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def export_report(folder,report):
 s=bd.import_step(folder/'assembly.step');parts={p.label:p for p in s.children}
 labels={'frame':'whoop_frame_with_ESC_posts','sled':'removable_battery_sled','esc':'HAKRC_HK10AX4_admission_envelope','fc':'Whoop_F405_Rev_A','radio':'FPV_radio_and_boost_envelopes','adhesive':'module_adhesive_pads','esc-screws':'ESC_mount_hardware','sled-screws':'sled_mount_hardware','battery':'battery_pack_in_sled','straps':'battery_straps_and_pads','dock':'snap_dock','camera':'fpv_camera','canopy':'snap_canopy','fc-mount':'stack_hardware'}
 groups={k:parts[v] for k,v in labels.items()};g=groups
 rad=g['radio'].children;groups.update({p.label:p for p in rad})
 # Re-measure actual group positions in assembly STEP; never read generator placement variables.
 esc_xy=[(-8,-8),(-8,8),(8,-8),(8,8)];sled_xy=[(-14,-8.5),(-14,8.5),(14,-8.5),(14,8.5)]
 expected_fc=[(-18.3848,0),(0,-18.3848),(0,18.3848),(18.3848,0)]
 D=[];measurements={}
 def check(n,v,ok,guide):
  D.append({'id':n,'measured':v,'requirement':guide,'pass':bool(ok)});print(n,v,bool(ok),flush=True)
 check('printed single valid solids',{k:len(g[k].solids()) for k in ['frame','sled']},all(len(g[k].solids())==1 and g[k].is_valid for k in ['frame','sled']),'one each')
 for key,p,r,expected in [('frame ESC bores',g['frame'],1.1,esc_xy),('ESC board bores',g['esc'],1,esc_xy),('sled pilots',g['sled'],.625,sled_xy),('original PCB grommet bores',g['fc'],1.5,expected_fc)]:
  m=axes(p,r);check(key+' XY',m,all(x in m for x in expected),'all four specified axes present, mm')
 for one,two in [('fc','frame'),('fc','fc-mount'),('fc','dock'),('fc','canopy'),('fc','camera'),('fc','esc-screws'),('esc','frame'),('esc','esc-screws'),('esc','sled'),('esc','straps'),('esc','battery'),('esc','radio'),('sled','frame'),('sled','battery'),('sled','straps'),('radio','sled'),('radio','battery'),('radio','straps'),('radio','esc-screws'),('radio','sled-screws'),('radio','adhesive')]:
  a,b=g[one],g[two];v=overlap(a,b);d=dist(a,b)
  check(one+' / '+two,{'overlap_mm3':v,'clearance_mm':d},v<.001,'zero positive solid interference; designed seating contacts permitted')
 eh=list(g['esc-screws'].children)
 nuts=[b for b in eh if b.label.startswith('ESC_nut_')]
 screws=[b for b in eh if b.label.startswith('ESC_M2x8_')]
 check('ESC fastener count',{'screws':len(screws),'nuts':len(nuts)},len(nuts)==len(screws)==4,'one screw and one nut per board hole')
 heights=[round(bb(a)[1][2]-bb(n)[1][2],4) for a,n in zip(screws,nuts)]
 check('M2 thread protrusion beyond captured nuts',heights,all(.8<=z<=1.2 for z in heights),'0.80 to 1.20 mm nominal tip extension beyond full nut')
 motor_hole=axes(g['frame'],.8);check('sled through bores XY',motor_hole,all(x in motor_hole for x in sled_xy),'four sled axes in main frame')
 for key,body in [('frame',g['frame']),('flight-board',g['fc']),('ESC',g['esc'])]:
  v=overlap(g['sled-screws'],body)
  check('sled screws vs '+key,v,v<.001,'no positive unintended volume')
 bite=overlap(g['sled-screws'],g['sled'])
 check('sled thread forming pilot engagement',bite,0<bite<5.,'intentional modeled straight thread blank / pilot interference in printed attachment below frame, mm3')
 for name,q in [('revised-frame',g['frame']),('battery-RF-sled',g['sled'])]:measurements[name+'_solid_volume_mm3']=round(q.volume,3)
 m=g['radio'].children
 for i in range(len(m)):
  for j in range(i):
   d=dist(m[i],m[j]);check(m[i].label+' / '+m[j].label,d,d>=.5,'module body separation >=0.50 mm')
 substrate=next(n for n in g['fc'].descendants if n.label and n.label.endswith('_PCB'))
 card=bb(substrate); installed=bb(g['fc']); check('installed FC geometry',{'bounds':installed,'substrate_reference':card},abs(installed[0][2]-3.50)<.015 and installed[1][2]<6.00,'board reference bottom at Z=3.50 ±0.015 mm and fitted parts below Z6.00 mm')
 # OCP descendant is locally registered, so substrate bounding box may report native bottom rather than installed plane.
 level={k:bb(g[k]) for k in ['radio','esc','sled','battery','straps','fc','frame']};measurements['installed_group_bounding_boxes_mm']=level
 check('ESC dimensional allocation',level['esc'],all(abs(level['esc'][1][i]-level['esc'][0][i]-a)<.005 for i,a in enumerate((20,22,4))),'20 x 22 mm published XY, 4.00 mm allocated Z')
 expected={'TBS_UNIFY_PRO32_Nano_fit_envelope':[15,13,3.],'BETAFPV_ELRS_Lite_Flat_1_2_fit_envelope':[11,10,3.],'Pololu_U3V16F5_no_headers_fit_envelope':[8.128,13.208,2.54]}
 for m in rad:
  a,b=bb(m);ext=[round(b[i]-a[i],4) for i in range(3)];check(m.label,{'extent_mm':ext,'bounds_mm':[a,b]},ext==expected[m.label],'manufacturer size or documented allowance in board guide')
  steel=dist(m,g['sled']);check(m.label+' pocket-fit',steel,steel>=.345,'min 0.35 mm adhesive seat or greater')
 guard={}
 for rad0 in [16.3,17.7]:
  a=axes(g['frame'],rad0)
  if a:guard[str(rad0)]=a
 sweeps=[]
 # Highest and lowest actual mesh blade extent from source stock propeller group; centers read from unchanged cylindrical inner guard walls.
 props=[p for p in parts if p.startswith('propulsion')]
 cp=next(c for c in parts[props[0]].descendants if c.label and c.label.startswith('prop_'));zb=bb(cp);safe_discs=[]
 for x,y in guard['16.3']:safe_discs.append(bd.Solid.make_cylinder(15.5,zb[1][2]-zb[0][2],bd.Plane(origin=(x,y,zb[0][2]))))
 swept=bd.Compound(children=safe_discs)
 for k in ['dock','canopy','camera','fc','esc','radio','sled']:
  p=g[k];vol=overlap(swept,p);d=dist(swept,p);check('prop swept volume / '+k,{'overlap_mm3':vol,'clearance_mm':d},vol<.001 and d>.20,'zero overlap and >0.20 mm design clearance')
 raised=bd.Pos(0,0,2.)*g['dock'];vol=overlap(raised,swept);check('rejected alternative raising dock 2 mm',vol,vol>0,'negative control must intersect conservative swept cylinders')
 # Proof of source provenance does not imply a measured purchased unit, electronics behavior, or flight performance.
 data={'method':'Independent OCCT BRep import of assembled STEP. Nominal mounted envelopes and conservative full-diameter rotor swept cylinders.','inputs':{'assembly.step':fingerprint(folder/'assembly.step'),'flight-controller.step':fingerprint(folder/'components/flight-controller.step')},'measurements':measurements,'checks':D,'verified':all(d['pass'] for d in D)}
 report.write_text(json.dumps(data,indent=2)+'\n');return data['verified']
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('report',type=Path);a=p.parse_args();raise SystemExit(0 if export_report(a.folder,a.report) else 1)
