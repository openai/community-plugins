# Whoop 65 with the F405 Rev A flight controller

Open [the offline aircraft viewer](Aircraft/viewer.html) for the complete quad, or open [the native board project](Flight-controller/design/Whoop-F405-A.kicad_pro) in KiCad. The custom controller replaces the integrated board. A purchased motor stage, receiver, video transmitter and 5 V regulator have separate measured locations in the removable battery/electronics sled.

| Folder | Contents |
| --- | --- |
| [Aircraft](Aircraft/README.md) | Complete STEP and colored GLB, 19 installed-coordinate component STEPs, four printable airframe parts, two snap coupons, two BOM worksheets, the editable mechanical recipe and its rebuild runner. |
| [Flight-controller](Flight-controller/) | Native schematic, board layout, local footprints and package models, manufacturing outputs, placement and exact part data, and electronic inspection records. |
| [Procurement](Procurement/fabrication-and-procurement.md) | Aircraft and child-BOM workbook, part identifiers and sourcing, dated supplier and price records, and outstanding quote/assembly work. |
| [Runtime](Runtime/README.md) | Offline KiCad 9.0.2 rebuild runner and Dockerfile for preparing its image. |
| [Evidence](Evidence/README.md) | Actual STEP alternatives for the 2 mm dock change, rejected and corrected pocket/canopy evidence, and the clean rebuild comparison. |

The aircraft-level BOM counts 32 installed rows with one assembled flight controller. The controller's 26 placements appear separately in the purchasing workbook. A 2 mm camera-dock lift enters two conservative rotor sweeps, so the revised frame holds the ESC below the deck. The candidate ESC envelope retains a 4.00 mm total height allocation; the bought unit still needs measurement. Sustained full-power current, RF performance, flight firmware, physical assembly and flight remain open.

Use the [presenter's prompts and exact replay](../Presentation/Prompt-runbook.md) to run the design in Codex Desktop.
